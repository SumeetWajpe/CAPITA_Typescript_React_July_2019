import React from 'react';

interface ButtonProps{
    count:number;
}
interface ButtonState{
    currCount:number;
}
export class Button extends React.Component<ButtonProps,
ButtonState>{
    constructor(props:ButtonProps){
        super(props);
        this.state = {currCount:this.props.count};
    }
    IncrementHandler(){
            // increment the count
            this.setState({currCount:this.state.currCount+1})
    }
    render(){
      return <button className="btn btn-primary" 
      onClick={this.IncrementHandler.bind(this)}>
                        {this.state.currCount}
                </button>
    }
  }