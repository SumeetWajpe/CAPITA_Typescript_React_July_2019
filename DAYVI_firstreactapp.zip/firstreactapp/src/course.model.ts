export class CourseModel{
    constructor(public name:string,public duration:string){

    }
}