import React from 'react';
import { Button } from './button.component';


// interface ListOfButtonsState{
//     buttons:number[];
// }


export class ListOfButtons extends React.Component<any,any>{
    private txtInput:React.RefObject<HTMLInputElement>;
    constructor(props:any){
        super(props);
        this.state = {buttons : [10,20,30,40,50]  };
        this.txtInput = React.createRef();
    }
    AddButtonHandler(){
            //this.buttons.push(70);
            let newButton;
            if(this.txtInput.current){                
                newButton = this.txtInput.current.value;
            }
              this.setState({buttons:[...this.state.buttons,newButton]})
    }
    render(){
        var buttonsToBeCreated = this.state.buttons.map((b:any)=>
        <Button count={b} />);      

      return <div>
                Enter a number : <input type="number" 
                ref={this.txtInput} />
                <button className="btn btn-success" 
                onClick={this.AddButtonHandler.bind(this)}>Add</button>
                <br/>
                {buttonsToBeCreated}
      </div>
    }
  }