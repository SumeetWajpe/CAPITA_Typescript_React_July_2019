import React from 'react';
import {CourseModel} from './course.model'
interface CourseProps{
   coursedetails:CourseModel;
}
export class Course extends React.Component<CourseProps>{
    constructor(props:CourseProps){
        super(props);
    }
    render(){
      return <div>
                        <h1>{this.props.coursedetails.name}</h1>
                        <h4>{this.props.coursedetails.duration}</h4>
                </div>
    }
  }