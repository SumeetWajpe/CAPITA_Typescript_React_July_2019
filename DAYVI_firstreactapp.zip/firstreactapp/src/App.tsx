import React from 'react';
import logo from './logo.svg';
import './App.css';
import { Course } from './course.component';
import { CourseModel } from './course.model';

class App extends React.Component{
  courses:CourseModel[] = [
      new CourseModel("React","3 Days"),
      new CourseModel("Redux","3 Days"),
      new CourseModel("Typescript","1 Day") ];
    render(){
    var coursesToBeCreated = this.courses.map((c)=> 
    <Course coursedetails={c} />);
    return <div>      
      {coursesToBeCreated}   
    </div>
  }
}

export default App;
