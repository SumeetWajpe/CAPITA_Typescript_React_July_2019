import {combineReducers} from 'redux';
import {courses} from './courses.reducer';
import {posts} from './posts.reducer';
export var rootReducer = combineReducers({
    posts,courses
});


// enhanced object literal - es 6

// var name ="Synechron";
// var city = "Pune";
// var company = {name:name,city:city};
// // OR
// var enhancedComp = {name,city};
