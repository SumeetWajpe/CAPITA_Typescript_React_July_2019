//create a store !

import {createStore} from 'redux';
import {rootReducer} from '../reducers/rootReducer';

var storeData = {
    posts:[{id:1,postarticle:'Post about Redux !'}],
    courses:[
        {id:1,name:'React',duration:'3 Days',likes:400,trainer:'Mr. Sumeet'},
        {id:2,name:'Redux',duration:'2 Days',likes:500,trainer:'Mr. Sumeet'},
        {id:3,name:'Angular',duration:'5 Days',likes:200,trainer:'Mr. Sujeet'},
        {id:4,name:'VueJs',duration:'2 Days',likes:600,trainer:'Mr. Abhijeet'},
        {id:5,name:'Typescript',duration:'2 Days',likes:100,trainer:'Mr. Ameet'}
    ]
}

// createStore(Reducer,StoreData)
export var store = createStore(rootReducer,storeData);