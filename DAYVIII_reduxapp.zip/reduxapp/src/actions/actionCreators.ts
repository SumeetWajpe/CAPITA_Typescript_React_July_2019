export function IncrementLikes(){
    return { type:'INCREMENT_LIKES' };
} 
export function AddPost(){
    return { type:'ADD_POST' };
} 
export function RemoveCourse(){
    return { type:'REMOVE_COURSE' };
} 