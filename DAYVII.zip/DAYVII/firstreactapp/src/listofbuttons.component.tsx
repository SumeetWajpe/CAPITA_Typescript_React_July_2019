import React from 'react';
import { Button } from './button.component';


// interface ListOfButtonsState{
//     buttons:number[];
// }


export class ListOfButtons extends React.Component<any, any>{
  private txtInput: React.RefObject<HTMLInputElement>;
  constructor(props: any) {
    super(props);
    this.state = {
      buttons: [{ id: 1, value: 10 }
        , { id: 2, value: 20 }, 
        { id: 3, value: 30 }, 
        { id: 4, value: 40 },
         { id: 5, value: 50 }
      ]
    };
    this.txtInput = React.createRef();
  }
  AddButtonHandler() {
    //this.buttons.push(70);
    let newButton;
    if (this.txtInput.current) {
      newButton = +(this.txtInput.current.value);
    }
    this.setState({ buttons: [...this.state.buttons, {id: this.state.buttons.length+1,value:newButton} ] })
  }

  DeleteButtonHandler() {

    let buttonToBedeleted: number;
    if (this.txtInput.current) {
      buttonToBedeleted = +(this.txtInput.current.value);
    }

    var newButtonList = this.state.buttons.filter((b: any) => b.value != buttonToBedeleted);
    this.setState({ buttons: newButtonList });

  }
  render() {
    var buttonsToBeCreated = this.state.buttons.map((b: any, index: number) =>
      <Button count={b.value} key={b.id} />);

    return <div>
      Enter a number : <input type="number"
        ref={this.txtInput} />
      <button className="btn btn-success"
        onClick={this.AddButtonHandler.bind(this)}>Add</button>
      <button className="btn btn-danger"
        onClick={this.DeleteButtonHandler.bind(this)}>Delete</button>

      <br />
      {buttonsToBeCreated}
    </div>
  }
}