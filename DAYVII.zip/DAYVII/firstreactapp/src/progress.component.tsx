import React from 'react';

export const Progress = (props:any) => {
    return (
        <div>          
            <img src="https://proxy.duckduckgo.com/iu/?u=https%3A%2F%2Fmedia1.tenor.com%2Fimages%2F672b62d967f8d00d608d22f36c1831db%2Ftenor.gif%3Fitemid%3D5388999&f=1" />
        </div>
    )    
}

export default Progress;