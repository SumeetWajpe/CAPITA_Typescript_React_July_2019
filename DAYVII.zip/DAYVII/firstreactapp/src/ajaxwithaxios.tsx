import React from 'react';
import axios from 'axios';
import Progress from './progress.component';

export class Posts extends React.Component<any,any>{
    
    constructor(props:any){
        super(props);
        this.state = {allPosts:[]};
    }
    componentDidMount(){
        //ajax
       var promise =  axios.get('https://jsonplaceholder.typicode.com/posts')
       promise.then((response)=>{
           this.setState({allPosts:response.data});           
       },(err)=>{
            console.log(err)
       });
    }
    render(){

        var postsTobcreated = this.state.allPosts.map((p:any)=> <li key={p.id}>{p.title}</li>)
            
            if(postsTobcreated.length == 0){
                postsTobcreated = <Progress />
            }else{
             postsTobcreated =   <ul>
                                                    {postsTobcreated}
                                                </ul>
            }

            return <div>
                <h1> All Posts </h1>
                {postsTobcreated}
            </div>
        }
}