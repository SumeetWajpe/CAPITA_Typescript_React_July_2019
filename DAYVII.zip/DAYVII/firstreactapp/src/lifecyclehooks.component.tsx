import React from 'react'

export class LifeCycleHook extends React.Component<any,any>{
    public txtCompany:React.RefObject<HTMLInputElement>;

    constructor(props:any){
        super(props);
        this.txtCompany = React.createRef();
        this.state = {companyName:''};
        console.log('Within Constructor !');
    }
    componentWillMount(){
        // initialize component
        console.log('Within componentWillMount !');
    }
    componentDidMount(){
        // ajax request + integration with other frameworks + timers
        console.log('Within componentDidMount !');
    }

    ChangeHandler(){
        console.log('Within ChangeHandler !');

        var company;
        if(this.txtCompany.current){
            company= this.txtCompany.current.value;
        }
       this.setState({companyName:company});
       
    }

    shouldComponentUpdate(){
        console.log('Within shouldComponentUpdate !');
        console.log(this.state);
        return true;
    }

    componentWillUpdate(){
        console.log('Within componentWillUpdate !');
        console.log(this.state);
    }

    componentDidUpdate(){
        console.log('Within componentDidUpdate !');
    }

    render(){
        console.log('Within render !');
        console.log(this.state);

        
        return(
            <div>
                Enter Company Name : <input type="text" 
                ref={this.txtCompany}
                onChange={this.ChangeHandler.bind(this)}
                 />
                  <h1> {this.state.companyName}</h1>
            </div>
        )
    }
}

export default LifeCycleHook