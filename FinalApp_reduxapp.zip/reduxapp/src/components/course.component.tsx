import React from 'react';


const CourseComponent: any = (props:any) => {
   
  return (
    <div className="col-md-3 courseStyle">
        <div className="row">
            <div className="col-md-9">
                <h3>{props.coursedetails.name}</h3>
            </div>   
            <div className="col-md-3">
            <button className="btn btn-danger"
            
            onClick={props.RemoveCourse.bind(null,props.coursedetails.id)}>
                    <span className="glyphicon glyphicon-trash">                        
                    </span>
               </button>
            </div>
        </div>
        <div className="row">
            <div className="col-md-5">
                <img className="img-thumbnail" src="https://proxy.duckduckgo.com/iu/?u=http%3A%2F%2Fmaestroselectronics.com%2Fwp-content%2Fuploads%2F2017%2F12%2FNo_Image_Available.jpg&f=1" />
            </div>           
            <div className="col-md-7">
                <h6>Duration : {props.coursedetails.duration}</h6>
                <h6>Trainer :{props.coursedetails.trainer}</h6>
            </div>
        </div>
        <div className="row">       
            <div className="col-md-3">
               <button className="btn btn-primary" 
               onClick={props.IncrementLikes.bind(null,props.coursedetails.id)}>
     

               {props.coursedetails.likes}
                    <span className="glyphicon glyphicon-thumbs-up">
                        
                    </span>
                    
               </button>
            </div>
        </div>

    </div>
  );
}

export default CourseComponent;
