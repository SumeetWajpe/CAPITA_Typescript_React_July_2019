import React from 'react';
import Course from './course.component';


const ListofCoursesComponent: any = (props:any) => {
  
  var coursesToBeCreated = props.allcourses.map((course:any) => <Course key={course.id} coursedetails={course} {...props}  />)

  return (
    <div>
      <div className="jumbotron">
          <h1> Courses </h1>        
      </div> 
      <div className="row">
            {coursesToBeCreated}
          </div>
    </div>
  );
}

export default ListofCoursesComponent;
