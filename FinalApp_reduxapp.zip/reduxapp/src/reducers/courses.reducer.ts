export function courses(defStore: any = [], action: any) {
        switch (action.type) {
                case 'INCREMENT_LIKES':
                        // make changes to store !
                        console.log(defStore);
                        let index = defStore.findIndex((c: any) => c.id == action.thecourseId)
                        return [
                                ...defStore.slice(0, index),
                                { ...defStore[index], likes: defStore[index].likes + 1 },
                                ...defStore.slice(index + 1)
                        ];


                case 'REMOVE_COURSE':

                        let newCourseList = defStore.filter((c: any) => c.id != action.thecourseId);
                        return newCourseList;
                        // Using thunk
                // case 'LOAD_COURSES':
                //                 return action.response.data;
                
                case 'LOAD_COURSES_SUCCEEDED':
                        return action.response;
                case 'LOAD_COURSES_FAILED':
                        return action.message;
                default:
                        return defStore;

        }
}