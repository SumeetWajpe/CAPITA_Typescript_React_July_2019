import {connect} from 'react-redux';
import { bindActionCreators,Dispatch } from 'redux';
import * as AllActions from './actions/actionCreators';
import App from './App';

//connect(mapStateToProps,mapDispatchToProps)

function mapStateToProps(storefromprovider:any){
    return {
        allposts:storefromprovider.posts,
        allcourses:storefromprovider.courses
    }
}

function mapDispatchToProps(dispatcher:Dispatch){
    return bindActionCreators(AllActions,dispatcher);
}
export var WrapperAppComponent = connect(mapStateToProps,mapDispatchToProps)(App);