import React from 'react';
import logo from './logo.svg';
import './App.css';
import CoursesComponent from './components/listofcourses.component';

export class App extends React.Component<any,any> {  
  
  componentDidMount(){
        this.props.LoadCourses();
  }
  render(){
    return  <div className="container">       
          <CoursesComponent {...this.props} />
      </div>    
  }
 
}

export default App;
