import {takeEvery,put,call} from 'redux-saga/effects';
import Axios from 'axios';

function* fetchCoursesData(){
    try {
        const coursesFromServer = yield call(Axios.get, "https://api.myjson.com/bins/dh07l");
        yield put({type: "LOAD_COURSES_SUCCEEDED", response :coursesFromServer.data});
     } catch (e) {
        yield put({type: "LOAD_COURSES_FAILED", message: e.message});
     }
}

export function* watchCoursesData(){
    yield takeEvery('LOAD_COURSES',fetchCoursesData)
}