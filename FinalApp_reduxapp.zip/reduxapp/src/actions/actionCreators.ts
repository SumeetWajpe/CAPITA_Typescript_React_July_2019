import axios from 'axios';

const INCREMENTLIKES = 'INCREMENT_LIKES';
export function IncrementLikes(thecourseId:number){
    return { type:INCREMENTLIKES,thecourseId };
} 
export function AddPost(){
    return { type:'ADD_POST' };
} 
export function RemoveCourse(thecourseId:number){
    return { type:'REMOVE_COURSE',thecourseId };
} 
// Using Thunk
// export function LoadCourses(){
//     // ajax request !
//     return (dispatch:any) => {
//         axios.get('https://api.myjson.com/bins/dh07l').then(
//          (response:any)=> dispatch({type:'LOAD_COURSES',response})
//         )
//       };    
// }

export function LoadCourses(){
    return {
        type:'LOAD_COURSES'
    }
}