var x = 100; // Type Inferencing
//x = "Hello"; // Error !
console.log(x);
var str; // Type annotation
var y;
y = 1000;
y = { name: 'Sumeet' };
y = ['Pune', 'Mumbai'];
var bool;
function Add(x, y) {
    return x + y;
}
var result = Add(10, 20);
console.log('Addition is : ' + result);
