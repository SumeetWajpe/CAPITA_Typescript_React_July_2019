import React from 'react';
import logo from './logo.svg';
import './App.css';
import CoursesComponent from './components/listofcourses.component';

const App: React.FC = (props:any) => {
  //  console.log(props); 
  return (
    <div className="container">       
        <CoursesComponent {...props} />
    </div>
  );
}

export default App;
