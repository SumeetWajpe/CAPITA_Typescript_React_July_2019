const INCREMENTLIKES = 'INCREMENT_LIKES';
export function IncrementLikes(){
    return { type:INCREMENTLIKES };
} 
export function AddPost(){
    return { type:'ADD_POST' };
} 
export function RemoveCourse(){
    return { type:'REMOVE_COURSE' };
} 