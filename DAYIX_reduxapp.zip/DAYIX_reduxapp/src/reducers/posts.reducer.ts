export function posts(defStore:any=[],action:any){
   switch (action.type) {
       case 'ADD_POST':
            // change the store !    
            console.log('Within posts reducer !');
            console.log('Action : ' + action.type);
            console.log(defStore);
            return defStore;            
       default:          
            return defStore;          
   }
    
   
}