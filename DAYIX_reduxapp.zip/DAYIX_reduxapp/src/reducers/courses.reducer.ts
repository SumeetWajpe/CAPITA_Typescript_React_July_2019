export function courses(defStore:any=[],action:any){
       switch (action.type) {
        case 'INCREMENT_LIKES':
             // make changes to store !
            console.log('Within courses reducer !');
            console.log(action);
            console.log(defStore);
            return defStore; 
        case 'REMOVE_COURSE':
                console.log('Within courses reducer !  ');
                console.log(action);
                return defStore;     
        default:
                return defStore;      

    }
}