let s = "Hello !";
var Square = (x) => x * x;
var result = Square(10);
