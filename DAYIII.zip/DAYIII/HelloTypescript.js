var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var x = 100; // Type Inferencing
//x = "Hello"; // Error !
console.log(x);
var str; // Type annotation
var y;
y = 1000;
y = { name: 'Sumeet' };
y = ['Pune', 'Mumbai'];
var bool;
function Add(x, y) {
    if (x < 0) {
        return 'X should be greater than 0 !';
    }
    return x + y;
}
var result = Add(10, 20);
console.log('Addition is : ' + result);
// Arrays
var cars = ['BMW', 'AUDI', 'FERRARI'];
// OR
var moreCars = new Array('TATA', 'MAHINDRA', 'MARUTI');
var allCars = cars.concat(moreCars); // Spread Operator
cars[0] = "HYUNDAI";
// for(var c in allCars){
//     console.log(c); // index
// }
// for(var c of allCars){
//     console.log(c);
// }
// allCars.forEach(function(theCar){
//     console.log(theCar);
// });
// ES 6 
if (true) {
    var blockScoped = 10;
    if (true) {
        console.log(blockScoped);
    }
}
// var  employee:IEmp = {name:'Amit',salary:50000};
var multilineString = "First Line\nSecond Line\nLast LIne !";
// class
var Car = /** @class */ (function () {
    // constructor();
    // constructor(name:string);
    // constructor(name:string,speed:number);
    // constructor(name:any,speed:any){}
    function Car(name, speed) {
        if (name === void 0) { name = "i20"; }
        if (speed === void 0) { speed = 100; }
        this.name = name;
        this.speed = speed;
    }
    Car.prototype.accelerate = function () {
        //console.log("The Car " + this.name + " is running at " + this.speed + " kmph !");
        return ("The car " + this.name + " is running at " + this.speed + " kmph !");
    };
    return Car;
}());
var cObj = new Car;
cObj.accelerate();
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(name, speed, fly, nitro) {
        var _this = _super.call(this, name, speed) || this;
        _this.canFly = fly;
        _this.useNitroPower = nitro;
        return _this;
    }
    JamesBondCar.prototype.accelerate = function () {
        return _super.prototype.accelerate.call(this) + " , Can It Fly ?" + this.canFly;
    };
    return JamesBondCar;
}(Car));
var jbc = new JamesBondCar("Aston Martin", 500, true, true);
console.log(jbc.accelerate());
var Emp = /** @class */ (function () {
    function Emp(name, salary) {
        this.name = name;
        this.salary = salary;
    }
    Emp.prototype.getDetails = function () {
        console.log("The emp " + this.name + " earns " + this.salary + " per month !");
    };
    return Emp;
}());
var empObj = new Emp("Aniket", 60000);
empObj.getDetails();
// Enhanced Class Syntax !
var EnhancedCar = /** @class */ (function () {
    function EnhancedCar(name, speed) {
        this.name = name;
        this.speed = speed;
    }
    return EnhancedCar;
}());
var enhancedCarObj = new EnhancedCar();
// Generics
function Swap(x, y) {
    var temp;
    temp = x;
    x = y;
    y = temp;
    console.log(x, y);
}
Swap(10, 20);
