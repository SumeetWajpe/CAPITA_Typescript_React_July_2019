"use strict";
exports.__esModule = true;
function Addition(x, y) {
    return x + y;
}
exports.Addition = Addition;
function Product(x, y) {
    return x * y;
}
exports.Product = Product;
