// export default function Addition(x:number,y:number):number{
//     return x + y;
// }
export  function Addition(x:number,y:number):number{
    return x + y;
}
export function Divide(x:number,y:number):number{
    return x / y;
}
export function Product(x:number,y:number):number{
    return x * y;
}
function Difference(x:number,y:number):number{
    return x - y;
}

