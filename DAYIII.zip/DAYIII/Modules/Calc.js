"use strict";
exports.__esModule = true;
var Math_1 = require("./Math");
console.log(Math_1.Addition(20, 50));
