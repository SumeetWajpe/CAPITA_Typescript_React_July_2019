// import Add,{Product} from './Math';
// console.log(Add(20,50));

import * as All from './Math';
All.Addition(20,30);