let s:string = "Hello !";

var Square = (x:any) => x*x;
var result:number = Square(10);