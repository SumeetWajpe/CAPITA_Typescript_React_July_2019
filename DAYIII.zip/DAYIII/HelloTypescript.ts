var x = 100; // Type Inferencing
//x = "Hello"; // Error !
console.log(x);
var str:string; // Type annotation
  
 var y:any;
y = 1000;
y = {name:'Sumeet'};
y = ['Pune','Mumbai'];

var bool:boolean;

function Add(x:number,y:number):number|string{
    
    if(x < 0){
        return 'X should be greater than 0 !';
    }
    return x + y;
}

var result:number|string = Add(10,20);
console.log('Addition is : ' + result);

// Arrays
var cars:string[] = ['BMW','AUDI','FERRARI'];
// OR
var moreCars:Array<string> = new Array<string>('TATA','MAHINDRA','MARUTI');

var allCars:string[] = [...cars,...moreCars];// Spread Operator
cars[0] = "HYUNDAI";

// for(var c in allCars){
//     console.log(c); // index
// }
// for(var c of allCars){
//     console.log(c);
// }
// allCars.forEach(function(theCar){
//     console.log(theCar);
// });


// ES 6 
if(true){
    let blockScoped = 10;
    if(true){
        console.log(blockScoped);
    }
}
//const PI ;
// PI= 3.14; //Error : decln + definition 
//PI = 3.14565;
// const company = {name:'CAPITA',location:'Pune'};
// company.name = "ACCENTURE";

// var person = {name:'Sachin',location:'Mumbai'};
// var player = {runs:50000};
// console.log(player);


// // Destructuring
// var companies = ['IBM',"Persitent","Accenture"];
// var firstCompany,secondCompany,thirdCompany;

// [firstCompany,,secondCompany,thirdCompany="CAPITA"] 
// = companies;

// with Objects
// var company = {title:'CAPITA',city:'Pune'};
// var {title,city} = company;

        // ------------Optional Parameters
// function PrintBooks(author?:string,title?:string){
//     // author = author || "Unknown";
//     // title = title || "Unknown";
//     console.log(title,author);
// }
        // PrintBooks();
// PrintBooks("Sachin Tendulkar","Playing It My Way");
        // -------------Default Parameters
// function PrintBooks(author:string="Unknown",title:string="Unknown"){    
//     console.log(title,author);
// }
// PrintBooks();
// PrintBooks("Sachin Tendulkar","Playing It My Way");
// PrintBooks(undefined,"UnknownTitle");
        //-------------- Rest parameters
// function PrintBooks(author:string,...titles:string[]){
//         console.log(author,titles)
// }
// PrintBooks("Dr. APJ Abdul Kalam","India 2020","Wings Of Fire");
// PrintBooks("Ranjit Desai","Mrutyunjay","Chava","Sambhaji Raje");


// Function Declaration
// function Square(x){
//     return x * x;
// }


// Function as an expresssion !
// var Square = function(x){
//     return x * x;
// }

// Arrow Functions
// var Square = (x) => {
//     return x * x;
// }

// OR

// var Square = x => x*x;
// var r = Square(10);

// usage !
//allCars.forEach(theCar=>console.log(theCar));

interface IEmp{
    name:string;
    salary:number;
    getDetails?():void;
}

// var  employee:IEmp = {name:'Amit',salary:50000};

var multilineString = `First Line
Second Line
Last LIne !`;

// class


class Car{
    private id:number;
     name:string;
    speed:number;
    // constructor();
    // constructor(name:string);
    // constructor(name:string,speed:number);
    // constructor(name:any,speed:any){}

    constructor(name:string="i20",speed:number=100){
        this.name = name;
        this.speed = speed;
   }
   accelerate():string{
       //console.log("The Car " + this.name + " is running at " + this.speed + " kmph !");
       return (`The car ${this.name} is running at ${this.speed} kmph !`);
   }
}

var cObj:Car = new Car
cObj.accelerate();


class JamesBondCar extends Car{
    canFly:boolean;
    useNitroPower:boolean;
    constructor(name:string,speed:number,fly:boolean,nitro:boolean){
        super(name,speed);
        this.canFly = fly;
        this.useNitroPower = nitro;
    }
    accelerate():string{
        return super.accelerate() + " , Can It Fly ?" + this.canFly;
    }
}
var jbc = new JamesBondCar("Aston Martin",500,true,true);
console.log(jbc.accelerate());


class Emp implements IEmp{
    name:string;
    salary:number;
    constructor(name:string,salary:number){
        this.name = name;
        this.salary = salary;
    }
    getDetails():void{
            console.log(`The emp ${this.name} earns ${this.salary} per month !`)
    }
}
class Manager implements IEmp{
    name:string;
    salary:number;
}
class FakeEmp{
}
// constraints in generics
class Company<T extends IEmp>{
    allEmps:T[];
}
var company = new Company<Emp>();
// var company = new Company<FakeEmp>(); // Error


var empObj:Emp = new Emp("Aniket",60000);
empObj.getDetails();

// Enhanced Class Syntax !
class EnhancedCar{   
    constructor(public name?:string,public speed?:number){

    }
}

var enhancedCarObj = new EnhancedCar();

// Generics

function Swap<T>(x:T,y:T){
    let temp:T;
    temp = x;
    x = y;
    y = temp;    
    console.log(x,y);
}
Swap<number>(10,20);

class Point<T,V>{
        x:T;
        y:V;
}

let pointobj = new Point<number,string>();